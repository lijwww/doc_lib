# -*- coding:utf-8 -*-
# show the allow hosts
# 
import json

def get_lines(hosts):
    """
    算出一个列表中，除去空字符串的行数
    """
    return len([host for host in hosts if host!=""])

def show_list(ami, group_file):
    """ 
    输出用户可登录设备列表
    vnd  　encode      others
    host1  host3       host4 
    host2  
    """
    try:
        with open(group_file, "rb") as fd: 
            datas = json.load(fd)
    except Exception,e:
        print Exception
        return False
    all_users = datas.get("users")
    all_groups = datas.get("groups")
    allow_groups = all_users.get(ami, [])
    if allow_groups == []:
        print "User (%s) not exist or has no privileges to access any group. " % ami
        return True
    allow_dict = {}
    for group in allow_groups:
        lines = all_groups.get(group, [])
        allow_dict.update({group: get_lines(lines)})
    allow_groups = [ i[0] for i in sorted(allow_dict.items(), key=lambda d: d[1], reverse=True)]
    #print lines #"{host:ip,host:ip..}"
    #print allow_groups #"[core,encode..]"
    #print allow_dict #"{core:233,encode:150..}"
    print "You have the account to this groups:",allow_groups
    allow_hosts_dict = {}
    format = '%-*s%-*s'
    for group in allow_groups:
        print "-"*10*5+group.upper()+"-"*10*5
        n = 1
        allow_hosts_dict.update(all_groups.get(group))
        for k,v in sorted(all_groups.get(group).items()):
            if n%2 != 0  and n != len(all_groups.get(group)):
                print format % (28,k,28,v),
            else:
                print format % (28,k,28,v)
            n+=1
    return allow_hosts_dict
    #hosts_len = len(all_groups.values()[0])
    #titles = "%26s"*len(allow_groups)
    #print "-"*26*5
    #print titles%tuple([ group.upper() for group in allow_groups])
    #print "-"*26*5
    #lenth = len(allow_groups)
    #line = "%26s"*lenth
    #print all_groups.values()
    #for group in allow_groups:
    #    print group
    #    print all_groups.get(group)
    #for i in range(hosts_len):
    #    value = [all_groups.get(group) for group in allow_groups]
    #    print line%tuple(value[i])
    #return True
    
def get_list(ami, group_file):
    """ 
    返回用户可登录设备字典
    {domain:ip}
    """
    try:
        with open(group_file, "rb") as fd: 
            datas = json.load(fd)
    except Exception,e:
        print Exception
        return False
    all_users = datas.get("users")
    all_groups = datas.get("groups")
    allow_groups = all_users.get(ami, [])
    if allow_groups == []:
        print "User (%s) not exist or has no privileges to access any group." % ami
        return False,{},{}
    allow_dict = {}
    for group in allow_groups:
        lines = all_groups.get(group, [])
        allow_dict.update({group: get_lines(lines)})
    allow_groups = [ i[0] for i in sorted(allow_dict.items(), key=lambda d: d[1], reverse=True)]
    
    allow_hosts_dict = {}
    for group in allow_groups:
        allow_hosts_dict.update(all_groups.get(group))
    return True, allow_groups, allow_hosts_dict

if __name__ == "__main__":
    #show_list("liyq","/data/group.json")
    get_list("liyq","/data/group.json")
