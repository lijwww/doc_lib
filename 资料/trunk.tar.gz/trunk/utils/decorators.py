#! /usr/bin/python 
# -*- coding:utf-8 -*-
"""
重试装饰器
Author qianzn
Email qianzn@bokecc.com
"""
import time

def retry(condition=False, default=False, times=4, delay=0.5):
    '''
    重试装饰器

    被修饰函数的执行结果result如果满足：result != condition，则认为执行成功。
    否则，装饰器执行重试
    重试times次后依然失败，装饰器告警

    @param condition: 重试条件，当被修饰函数返回结果为condition时进行重试
    @param default: 重试失败时的默认返回值
    @param times: 重试次数，默认为3
    @param delay: 重试等待时间，默认为0.5秒
    '''
    def decor_1(func):
        def decor_2(*args, **kwargs):
            for i in xrange(times):
                try:
                    result = func(*args, **kwargs)
                except RetryBreak, e:
                    print e
                    return default
                except Exception, e:
                    print e
                    return default

                if isinstance(result, RetryBreak):
                    return default
                
                elif result != condition:
                    return result
                elif i < times - 1:
                    time.sleep(delay)
            else:
                return default
        return decor_2
    return decor_1


class RetryBreak(Exception):
    '''retry 终止异常'''
    def __init__(self, message=None):
        self.message = message
        self.caller = trace_code(2)

    def __str__(self):
        if self.message is None:
            self.message = 'The retry decorator break at %s' % self.caller
        return str(self.message)


if __name__ == "__main__":
    @retry(condition=1, default = 0)
    def test(a,b):
        return (a+b)%2

    i = test(1, 2)
    print i
