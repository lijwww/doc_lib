#! /user/bin/python 
# -*- coding:utf-8 -*-

import os
import ConfigParser

"""
配置文件解析方法
"""
##  自定义一个类，继承Exception 
class FileNotExist(Exception):

    """
    def __init__(self,message):
        Exception.__init__(self)
        self.message=message   
    """
    pass

def parse(cpath):
    """
    """
    confs = {}
    cf = ConfigParser.ConfigParser()
    if not os.path.isfile(cpath):
       ## raise 引发异常
       raise FileNotExist, "Can't read configuration file: %s" % cpath
    ## 读取参数中的文件路径
    cf.read(cpath)
    ## 读取配置文件中的块
    secs = cf.sections()
    for sec in secs:
        ## 用ConfigParser类的options()方法获取每个section的内容
        options = cf.options(sec)
        for option in options:
            ## 获取option,value 的键值对到新字典
            confs.update({option: cf.get(sec,option)})
    return confs
    
if __name__ == "__main__":
    rets = parse("/etc/go.conf")
    print "conf:", rets

    
