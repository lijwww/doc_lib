#! /usr/bin/python
# -*- coding:utf-8 -*-

"""
参数解析方法

"""
from optparse import OptionParser

# 初始化help命令中useage的内容
MSG_USAGE = "c [ -u <user>][ -s <server>] arg1[, arg2...]\n       c [user@][server|host]"


def get_parser():
    """
    初始化参数参数解析对象
    """
    parser = OptionParser(MSG_USAGE)## 导入useage的初始化信息
    ## 添加options 内容
    """ 
    add_option()中的含义: 第一个参数，表示option的缩写，例如-u;
                          第二个参数，表示option的全拼，例如--user;
    后面的参数皆为命名参数，命名参数为可选参数:
    所有的action值如下：
        store + store_true + store_false + store_const + append + count + callback
        store_true和store_false 区别,如果参数没有出现，默认读取defalut的值。如果出现参数，则按照action的设置store_true则设置为true，store_false则设置为false
    所有type的值如下：默认为string
        string, int, choice, float and complex
    dest= 默认使用第二个参数的值。表示经过处理后在显示的option的key名
    default= 表示这个option的默认值
    metavar=:表示显示到help中option的默认值；
    const=:当action为store_const的时候，需要设置此值；
    choices=:当设置type为choices时，需要设置此值；
    """
    parser.add_option("-u", "--user",
                      action="store", type="string", dest="user", default="phenix", help=u"The user name to login")
    parser.add_option("-p", "--port",
                      action="store", type="string", dest="port", default="12", help=u"The port of ssh")
    parser.add_option("-s", "--server",
                      action="store",  type="string", dest="server", default=None, help=u"The server address")
    parser.add_option("-k", "--kuser",
                      action="store",  type="string", dest="kuser", default=None, help=u"Kerberos user name")
    #parser.add_option("-t", "--skip",
    #                  action="store_true", dest="skip", default=False, help=u"Skip getting kerberos tickets")
    parser.add_option("-c", "--conf",
                      action="store", dest="conf", default="/etc/go.conf", help=u"The configuration file")
    parser.add_option("-d", "--kdestroy",
                      action="store_true", dest="destroy", default=False, help=u"Destroy the kerberos tickets")
    parser.add_option("-l", "--list",
                      action="store_true", dest="list", default=False, help=u"Show the servers list in groups that you have privilege")
    return parser
    print parser

if __name__ == "__main__":
    parser = get_parser()
    opts, vals = parser.parse_args()
    print opts
    print vals
