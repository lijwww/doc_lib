#! /usr/bin/python
# -*- coding:utf-8 -*-
"""
彩色输出结果

支持以下文字颜色：
grey, red, green, yellow, blue, magenta, cyan, white

支持下列的背景高亮：
on_grey, on_red, on_green, on_yellow, on_blue, on_magenta, on_cyan, on_white

支持下列属性:
bold, dark, underline, blink, reverse, concealed(加粗,黑暗，下划线，闪烁，文字与背景颜色互换，隐藏)

函数colored, cprint 
colored("message","color",“background color”,attrs=["underline"])
cprint("message","color","background color",attrs=["underline"])

如果经常要用到复杂的颜色组合，可以用 lambda 来把参数抽象出来：
red_on_cyan = lambda x: colored(x, 'red', 'on_cyan')
print red_on_cyan('Hello, World!')

"""
from termcolor import colored


def error(msg):
    print colored(msg, "red")


def infor(msg):
    print colored(msg, "green")


def warning(msg):
    print colored(msg, "yellow")


if __name__ == "__main__":
    error("login error")
    infor("login success")
    warning("login abort")
