#! /usr/bin/python
# -*- coding:utf-8 -*-
"""
自动申请Kerberos票据
"""
import os
import sys
import time
import pexpect
import commands
import time
import re
from output import error, warning

CONDITIONS = [
    "(?i)Password:",
    "not found in Kerberos",
    pexpect.EOF,
    pexpect.TIMEOUT,
    "(?i)BOKECC.COM:"
]

class KrbNotExist(Exception):

    """
    """
    pass

class Kinit():

    def __init__(self, server, user, passwd):
        self.user = user
        self.passwd = passwd + "\n"
        self.server = server

    def have_ticket(self):
        all_tickets = self.check_ticket()
        return True if self.user in all_tickets else False

    def need_renew_ticket(self):
        cmd = "klist  -A |grep krbtgt |head -n1"
        try:
            rets = commands.getoutput(cmd)
        except Exception, e:
            print "klist -A |grep krbtgt |head -n1 excute faild"
            rets =""
        if rets == "":
            return True
        else:
            tm = rets.split()[2] + " " + rets.split()[3]
            if re.match(r'[0-9/\s:]{19}',tm):
                expire_time = time.mktime(time.strptime(tm,'%m/%d/%Y %H:%M:%S'))
            elif re.match(r'[0-9/\s:]{16}',tm):
                expire_time = time.mktime(time.strptime(tm,'%d/%m/%Y %H:%M'))
            now_time = time.mktime(time.localtime())
            #print expire_time , now_time
            if  now_time >= expire_time :
                return True
            else:
                return False

    def get_ticket(self):
        """获取票据 """
        if self.have_ticket():
            return True
        is_ok = False
        pcmd = "/usr/bin/kinit -p -f %s/%s" % (self.user, self.server)
        child = pexpect.spawn(pcmd)
        #child.logfile = sys.stdout
        index = child.expect(CONDITIONS)
        if index in (0, 4):
            child.sendline(self.passwd)
            for i in range(10):
                if self.have_ticket():
                    is_ok =True
                    break
                else:
                    time.sleep(1)
            if not is_ok:
                error(u"The ticket server password incorrect")
        elif index == 1:
            error(u"User does not exist in Kerberos")
        elif index == 3:
            error(u"Get user ticket timed out")
        else:
            warning(u"Can't get user login ticket")
        child.close()
        return is_ok

    def destory(self):
        """ 销毁已获取的票据"""

        cmd = "kdestroy -A"
        rets = commands.getoutput(cmd)
        return True if rets == "" else False

    def check_ticket(self):
        """ """
        cmd = "klist -A"
        rets = commands.getoutput(cmd)
        return rets

if __name__ == "__main__":
    kserver = "user@BOKECC.COM"
    kpasswd = "c#o!n=d#y"
    user = os.getenv("LOGNAME")
    k = Kinit(kserver, user, kpasswd)
    #k.destory()
    #isSuccess = k.get_ticket()
    print k.need_renew_ticket()
    
