#! /usr/bin/python
# -*- coding:utf-8 -*-
# 服务器自动登录脚本
# @Auther qianzn
# @Date 2015-03-02

import os
import re
import sys
import time
import json
import getpass
import pexpect
import struct, termios, fcntl

from utils.decorators import retry
from utils.show import show_list, get_list
from loadlib import krb, goconf
from loadlib.output import error, infor, warning


class AuthLoginExpection(Exception):

    """
    SSH Exception
    """
    pass


class AuthLogin():

    """ """
    ## 初始化执行函数，添加 日志文件路径
    def __init__(self, logfile_path=None):
        self.original_prompt = r"[#$]"   ## 定义提示符
        self.condition = ["(?i)are you sure you want to continue connecting",
                          self.original_prompt,
                          "(?i)(?:password:)|(?:passphrase for key)",
                          "(?i)terminal type",
                          pexpect.TIMEOUT,
                          "(?i)connection closed by remote host",
                          "(?i)connection refused",
                          "(?i)No route to host",
                          pexpect.EOF,
                          ] ##  定义通过expect执行ssh命令后的提示内容，根据返回的内容进行下一步操作
        self.logfile = None
        if (logfile_path is not None 
            and os.path.isdir(os.path.dirname(logfile_path))):
            self.logfile = open(logfile_path, "a")  ## 判断输入的日志文件是否存在，然后打开进行追加日志操作

    @retry(condition=0, default=2)
    def _doLogin(self, child, timeout):
        """
        尝试登录
        0 继续执行登录流程
        1 登录成功
        2 登录失败
        """
        if not isinstance(child, pexpect.spawn):
            raise AuthLoginExpection, "No access to login"

        index = child.expect(self.condition, timeout)
        #print index
        if index == 4:
            raise AuthLoginExpection, "Login timeout"
        if index == 5:
            raise AuthLoginExpection, "Connection closed by remote host"
        if index == 6:
            raise AuthLoginExpection, "Connection refused, try other port"
        if index == 7:
            raise AuthLoginExpection, "Host is unreachable"
        if index == 0:
            child.sendline("yes")
            return 0
        elif index == 1:
            return 1
        elif index == 2:
            passwd = getpass.getpass("input password: ")
            child.sendline(passwd)
            time.sleep(1)
            return 0
        elif index == 3:
            child.sendline("ansi")
            return 0
        else:
            raise AuthLoginExpection, "Fail to connect the host"

    def login(self, user="phenix", server=None, port="12", timeout=30):
        """
        执行登录动作,并记录用户执行命令
        @params user 用户名
        @params server 服务器地址或主机名
        @params port 端口号
        @parmas timeout 超时时间
        @return None
        """
        if server is None:
            error(u"Host address not specified")
            return False
        ##记录登录前屏幕尺寸
        s= struct.pack("HHHH",0,0,0,0)
        a= struct.unpack('hhhh', fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ , s))
        cmd = "/usr/bin/ssh -p{port} {user}@{server}".format(port=port,
                                                             user=user,
                                                             server=server)
        child = pexpect.spawn(cmd)
        if self.logfile is not None:
            child.logfile = self.logfile
        result = self._doLogin(child, timeout)
        if result == 1:
            #child.sendline()
            ##恢复尺寸大小
            child.setwinsize(a[0],a[1])
            try:
                child.interact()
            except OSError:
                infor(u"Server disconnected")
            else:
                infor(u"Server disconnected")
        else:
            try:
                error(u"Server login abnormal")
                raise AuthLoginExpection
            except AuthLoginExpection:
                self.logfile.close()
                child.close()
                return False
        try:
            child.expect(pexpect.EOF)
            self.logfile.close()
            child.close()
        except Exception,e:
            print e
            infor(u"Thread close exception")
        return True


def get_tickit(server, user, passwd, isDestory):
    """
    获取krb票据
    """
    krber = krb.Kinit(server, user, passwd)
    if isDestory:
        krber.destory()
    rets = krber.get_ticket()
    if not rets:
        warning(u"Unable to get server login credentials")
    return rets


def parse_opts(parser, ami):
    """ 
    解析用户数据参数
    """
    parses, options = parser.parse_args()
    server = parses.server
    user = parses.user
    port = parses.port
    try:
        confs = goconf.parse(parses.conf)
    except goconf.FileNotExist, e:
        error(e)
        return False
    group_file = confs.get("groupath")
    unmonitored_host_file = confs.get("unmopath")
    vip_file = confs.get("vippath")
    if parses.kuser != None:
        ami = parses.kuser
    if parses.list:
        show_list(ami, group_file)
        sys.exit(0)
    if options:
        options = options[0]
        if "@" in options:
            user, server = options.split("@")
        else:
            server = options
    else:
        if server == None:
            error(u"Host address not specified")
            return False

    ## load server with muti ip info
    try:
        with open(vip_file, "rb") as fd:
            vip_info = json.load(fd)
    except Exception,e:
        vip_info = {}
    ## load unmonitor json
    try:
        with open(unmonitored_host_file, "rb") as fd:
            um = json.load(fd)
    except Exception,e:
        um = {}
    ## get accessable json
    allow_dict = {}
    allow_hosts_dict = {}
    get_ok, allow_dict, allow_hosts_dict = get_list(ami, group_file)
    if not get_ok :
        sys.exit(0)
    #print allow_dict, allow_hosts_dict
    infor(u"Your accessable groups are as follows:")
    titles = "%10s"*len(allow_dict)
    print "-"*15*5
    print titles%tuple([ group.upper() for group in allow_dict])
    print "-"*15*5
    ## 对输入的服务器信息进行处理
    p = re.compile('^((25[0-5]|2[0-4]\d|[1]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[1]?\d\d?)$')
    if p.match(server):
        vip_server = vip_info.get(server)
        s1 = {value:key for key,value in allow_hosts_dict.items()}.get(server)
        if s1 is None and vip_server is None:
            error(u"You have no privilege to login this server")
        elif s1 is None and vip_server is not None :
            infor(u"The IP you want to login is an VIP,I'll try..")
            server = vip_server
        else:
            if um.get(server) is not None:
                infor(u"Server monitor status is cloesed in ab!!!")
            server = s1
    elif ".bokecc.com" not in server:
        #print "is short domain %s" % server
        server+='.bokecc.com'
        s2 = allow_hosts_dict.get(server)
        if s2 is None:
            error(u"You have no privilege to login this server")
        else:
            if {value:key for key,value in um.items()}.get(server) is not None:
                infor(u"Server monitor status is cloesed in ab!!!")
    else:
        #print "is long domain %s"  % server
        s3 = allow_hosts_dict.get(server)
        if s3 is None:
           error(u"You have no privilege to login this server")
        else:
            if {value:key for key,value in um.items()}.get(server) is not None:
                infor(u"Server monitor status is cloesed in ab!!!")
    #print server
    logpath = confs.get("logpath")
    if os.path.isdir(logpath) is False:
        os.makedirs(logpath)
    logfile = logpath + ami

    kuser = ami
    if parses.kuser:
        kuser = parses.kuser
    kserver = "user@BOKECC.COM"
    kpasswd = "c#o!n=d#y"
    kerberos = krb.Kinit(kserver, kuser, kpasswd)
    #print "销毁票据",parses.destroy
    #print "需要重新获取票据",kerberos.need_renew_ticket() 
    if kerberos.need_renew_ticket() or parses.destroy : ## 默认跳过重新获取票据。如果带参数-d 或者检查到需要重新获取票据，则重新获取票据后登陆
        parses.destroy = True
        get_tickit(kserver, kuser, kpasswd, parses.destroy)
    
    loginer = AuthLogin(logfile)
    loginer.login(user, server, port)

if __name__ == "__main__":
    from loadlib import parse

    ami = os.getenv("LOGNAME")

    parser = parse.get_parser()

    try:
        parse_opts(parser, ami)
    except KeyboardInterrupt:
        print "  go command interrupted"
